package com.assignment.ElkDocs

import android.content.Intent
import android.os.Bundle
import android.view.animation.LinearInterpolator
import android.view.animation.RotateAnimation
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.assignment.ElkDocs.databinding.ActivityMainBinding
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private lateinit var secondHand: ImageView
    private lateinit var minuteHand: ImageView
    private lateinit var hourHand: ImageView
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        secondHand = findViewById(R.id.secondHand)
        minuteHand = findViewById(R.id.minuteHand)
        hourHand = findViewById(R.id.hourHand)

        startClock()

        binding.switchToComposeButton.setOnClickListener {
            val intent = Intent(this, JetpackClock::class.java)
            startActivity(intent)
        }
    }

    private fun startClock() {
        val calendar = Calendar.getInstance()
        val currentSecond = calendar.get(Calendar.SECOND)
        val currentMinute = calendar.get(Calendar.MINUTE)
        val currentHour = calendar.get(Calendar.HOUR)

        rotateHand(secondHand, 360f / 60 * currentSecond, 60 * 1000)
        rotateHand(minuteHand, 360f / 60 * currentMinute, 60 * 60 * 1000)
        rotateHand(hourHand, 360f / 12 * currentHour, 12 * 60 * 60 * 1000)
    }

    private fun rotateHand(hand: ImageView, fromDegrees: Float, duration: Long) {
        val rotate = RotateAnimation(
            fromDegrees, fromDegrees + 360,
            RotateAnimation.RELATIVE_TO_SELF, 0.5f,
            RotateAnimation.RELATIVE_TO_SELF, 0.5f
        )
        rotate.duration = duration
        rotate.interpolator = LinearInterpolator()
        rotate.repeatCount = RotateAnimation.INFINITE
        hand.startAnimation(rotate)
    }
}
