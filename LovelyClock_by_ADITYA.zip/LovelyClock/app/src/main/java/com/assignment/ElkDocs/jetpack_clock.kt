package com.assignment.ElkDocs

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.example.clockanimation.ui.theme.ClockAnimationTheme
import java.util.Calendar

class JetpackClock : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ClockAnimationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Clock()
                }
            }
        }
    }
}

@Composable
fun Clock() {
    val calendar = remember { Calendar.getInstance() }

    val secondAngle by rememberInfiniteTransition().animateFloat(
        initialValue = (calendar.get(Calendar.SECOND) * 6).toFloat(),
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(60 * 1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    val minuteAngle by rememberInfiniteTransition().animateFloat(
        initialValue = (calendar.get(Calendar.MINUTE) * 6).toFloat(),
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(60 * 60 * 1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    val hourAngle by rememberInfiniteTransition().animateFloat(
        initialValue = (calendar.get(Calendar.HOUR) * 30).toFloat(),
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12 * 60 * 60 * 1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {

//        LottieAnimation(composition = rememberLottieComposition(spec = LottieCompositionSpec.Asset(anim2.json))

        Canvas(modifier = Modifier.size(200.dp)) {

            drawCircle(Color.hsl(45f, 0.7f, 0.5f), style = Stroke(width = 10.dp.toPx()))
//            , center = center, radius = size.minDimension / 2)


            rotate(degrees = hourAngle, pivot = center) {
                drawLine(
                    Color.Black,
                    start = center,
                    end = center.copy(y = center.y - 50.dp.toPx()),
                    strokeWidth = 8.dp.toPx()
                )
            }

            rotate(degrees = minuteAngle, pivot = center) {
                drawLine(
                    Color.Black,
                    start = center,
                    end = center.copy(y = center.y - 70.dp.toPx()),
                    strokeWidth = 4.dp.toPx()
                )
            }

            rotate(degrees = secondAngle, pivot = center) {
                drawLine(
                    Color.Red,
                    start = center,
                    end = center.copy(y = center.y - 90.dp.toPx()),
                    strokeWidth = 2.dp.toPx()
                )
            }
        }
    }
}
